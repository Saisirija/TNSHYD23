package encapsulation;

public class Studentmain 
{
	public static void main(String[] args) 
	{
		Student s1 = new Student();		
		s1.setName("maxi");
		s1.setAge(19);
		
		System.out.println(s1.eligible());
	}

}
