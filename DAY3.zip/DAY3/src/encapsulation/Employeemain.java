package encapsulation;

public class Employeemain {
	public static void main(String[] args) 
	{
		Employee e1 = new Employee();
		e1.setName("shashi");
		e1.setId(1);
		e1.setSalary(100000);
		
		System.out.println(e1.Grade());
	}

}
