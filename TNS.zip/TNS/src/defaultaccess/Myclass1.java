package defaultaccess;

public class Myclass1 {
	void display()
	{
		System.out.println("Hello world");
	}

}
