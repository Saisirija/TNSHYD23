package userdefined1;

public class Z {
	public void msg()
	{
		System.out.println("Hello D");
	}

}
