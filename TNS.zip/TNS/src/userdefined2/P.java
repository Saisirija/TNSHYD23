package userdefined2;
import userdefined.*;
import userdefined1.Z;

public class P {
	public static void main(String[] args) 
	{
		X obj = new X();
		Y obj1 = new Y();
		Z obj2 = new Z();
		
		obj.msg();
		obj1.msg();
		obj2.msg();
		
	}

}
