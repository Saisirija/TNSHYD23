package approach2;

public class Animal {
	public int a=10;
	static int b=20;
	int sound()
	{
		return 10;
	}
	static void sound1()
	{
		System.out.println(b);
	}

}
