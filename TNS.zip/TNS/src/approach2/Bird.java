package approach2;

public class Bird {
	public static void main(String[] args) {
		Animal a1 =new Animal();
		System.out.println(a1.a);
		a1.sound();
		
		System.out.println(Animal.b);
		Animal.sound1();
	}
}
