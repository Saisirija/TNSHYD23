package privateaccess;

public class P {
	private void display()
	{
		System.out.println("TNS day 2");
	}
	public static void main(String[] args) {
		P obj = new P();
		obj.display();
	}

}
