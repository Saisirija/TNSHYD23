package approach1;

public class Animal {
	int a=10;
	static int b=20;
	int sound()
	{
		return 10;
	}
	static  void sound1()
	{
		System.out.println(b);
	}
	public static void main(String[] args) {
		Animal a1 = new Animal();
		System.out.println(a1.a);
		a1.sound();
		System.out.println(Animal.b);
		Animal.sound1();
		
	}
	
}
