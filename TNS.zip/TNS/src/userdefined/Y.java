package userdefined;

public class Y {
	public void msg()
	{
		System.out.println("Hello Y");
	}

}
