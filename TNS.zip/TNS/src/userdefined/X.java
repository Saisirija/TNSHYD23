package userdefined;

public class X 
{
	public void msg()
	{
		System.out.println("Hello X");
	}
}
