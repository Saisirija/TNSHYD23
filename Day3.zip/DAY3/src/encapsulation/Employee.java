package encapsulation;

public class Employee {
	
	private String name;
	private int id;
	private int salary;
	public Object setName;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public String Grade()
	{
		if(salary >= 80000)
		{
			return " GRADE A";
		}
		else if (salary >= 60000 ) 
		{
			return " GRADE B";
		}
		else if (salary >= 40000)
		{
			return "GRADE C";
		}
		else
		{
			return "GRADE D";
		}
	}
	
}
