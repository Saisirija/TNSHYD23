package encapsulation;

public class Resultsmain 
{
	public static void main(String[] args) 
	{
		Results res = new Results();
		
		res.setId(3);
		res.setName("Rocky");
		res.setYear(4);
		res.setBranch("CSE");
		res.setMarks(78);
		
		System.out.println(res.Secured());
	}

}
