package encapsulation;

public class Results {
	
	private int Id;
	private String Name;
	private int Year;
	private String Branch;
	private int Marks;
	
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	public int getMarks() {
		return Marks;
	}
	public void setMarks(int marks) {
		Marks = marks;
	}
	
	public String Secured()
	{
		if(Marks >= 90)
		{
			return "GRADE A+";
		}
		else if(Marks >= 80)
		{
			return "GRADE A";
		}
		else if(Marks >= 70)
		{
			return "GRADE B+";
		}
		else if (Marks >= 60)
		{
			return "GRADE B";
		}
		else if(Marks >= 50)
		{
			return "GRADE C";
		}
		else
		{
			return "FAIL";
		}
		
	}

}
